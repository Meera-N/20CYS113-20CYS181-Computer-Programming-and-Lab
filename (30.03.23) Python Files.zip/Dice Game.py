import random
random.seed()   #Prepare random number generator

print("Do you want to play? Type Yes or No")
ans = input()
if ans == "Yes" or ans == "yes" or ans == "Y" or ans == "y":
    userno = int(random.random() * 7)
    compno = int(random.random() * 7)
    print("Computer's dice is " + str(compno))
    print("User's dice is " + str(userno))
    if userno == compno:
        print("Congrats! Its a tie")
    else:
        if userno > compno:
            print("Congrats! You have won")
        else:
            print("Aw, too bad..Try again next time")
else:
    print("Too bad..")
