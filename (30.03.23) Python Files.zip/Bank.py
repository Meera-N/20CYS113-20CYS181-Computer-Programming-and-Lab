balance = [0] * (2)

print("Welcome to Bank. Please enter your 5 digit account number.")
accno = int(input())
if accno <= 99999 and accno >= 10000:
    print("Please enter balance in account no:" + str(accno))
    bal = float(input())
    if bal > 500:
        balance[0] = bal
        print("What would you like to do?")
        print("For withdrawal, enter 1")
        print("For deposition, enter 2")
        print("For referral, enter 3")
        opt = int(input())
        if opt == 1:
            print("Enter amount to be withdrawn")
            wd = float(input())
            bal = bal - wd
        else:
            if opt == 2:
                print("Enter amount to be deposited")
                dp = float(input())
                bal = bal + dp
            else:
                if opt == 3:
                    print("Please type in 4 digit referral code")
                    cde = int(input())
                    if cde >= 1000 and cde <= 9999:
                        print("Valid code. $20 has been credited to your account")
                        bal = bal + 20
                    else:
                        print("Invalid")
                else:
                    print("Please enter valid option")
    else:
        print("You do not have minimum balance, please contact bank helpline")
    balance[1] = bal
    print("Thankyou for using our bank! Come back soon")
else:
    print("Please enter valid account number")
