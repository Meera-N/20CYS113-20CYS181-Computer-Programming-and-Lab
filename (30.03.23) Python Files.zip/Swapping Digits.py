print("Enter value for a")
a = int(input())
print("Enter the value for b")
b = int(input())
a = a * b
b = float(a) / b
a = float(a) / b
print("The value for a is " + str(a) + " while the value for b is " + str(b))
