n = 0
sum = 0
while n <= 10:
    sum = n + 1
    print(sum)
    n = n + 1
