num = 0
sum = 0
while num <= 10:
    sum = num + sum
    num = num + 1
print(sum)
