# largen is the largest number
values = [0] * (5)

for index in range(0, 4 + 1, 1):
    print("Enter the values to be stored in index=[" + str(index) + "]")
    value = int(input())
    values[index] = value
print("Array contents :")
for index in range(0, 4 + 1, 1):
    print("Array content values for [" + str(index) + "] is " + str(values[index]))
print("The largest element is :")

# using if statement to max
if values[0] > values[1] and values[0] > values[2] and values[0] > values[3] and values[0] > values[4]:
    print(values[0])
else:
    if values[1] > values[0] and values[1] > values[2] and values[1] > values[3] and values[1] > values[4]:
        print(values[1])
    else:
        if values[2] > values[1] and values[2] > values[0] and values[2] > values[3] and values[2] > values[4]:
            print(values[2])
        else:
            if values[4] > values[0] and values[4] > values[2] and values[4] > values[3] and values[4] > values[1]:
                print(values[4])
            else:
                print(values[3])
